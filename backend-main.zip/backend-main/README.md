This is template project spring
Spring version: 3.5.4
Gradle
Lombok
Mysql: Change DB, username, password at application.yml